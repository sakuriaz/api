from flask import *
import json

app = Flask(__name__)

@app.route('/', methods=["GET"])
def default():
    return json.dumps({"monkey": "True"})

@app.route('/version', methods=["GET"])
def version():
    with open('version.json', 'r') as file:
        data = json.loads(file.read())
        return json.dumps({"version": data["version"]})

@app.route('/source', methods=["GET"])
def source():
    with open("MonkeyRaider.pyc", "rb") as f:
        return f.read()


if __name__ == '__main__':
    app.run(port=7777)
